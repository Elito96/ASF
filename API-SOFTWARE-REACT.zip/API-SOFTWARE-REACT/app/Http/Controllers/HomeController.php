<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class HomeController extends Controller
{
    public function data(){
    	$user = DB::table('usuario')->where('ci', $_POST['ci'])->select('*')->get();
    	if(count($user) == 0){
    		return  response()->json([
			    'status' => 'NO',
			    'ci' => 'NO',
			]);
    	}
    	return response()->json([
    			'status' => 'YES',
			    'name' => $user[0]->name,
			    'ci' => $user[0]->ci,
			    'saldo' => $user[0]->saldo,
			    'tipo' => $user[0]->tipo
			]);
    }
    public function mapaview(){
    	dd($_POST['key']);
    	return view('map');
    }
}
